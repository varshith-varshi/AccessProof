# AccessProof Guard

1. Install Docker Desktop (Windows/macOS) or Docker Engine with Compose (Linux).
2. Double-click `start.command` on macOS, run `start.ps1` on Windows, or
   double-click/run `start.sh` on Linux.
3. Your browser opens the private setup page at `http://127.0.0.1:8080/setup`.
4. Create a Guard in AccessProof, paste its one-time token, enter the trusted
   OIDC issuer and audience used by your RAG, and select **Connect Guard**.

The setup page is bound to loopback and never receives remote scripts. The
one-time token is exchanged for a private machine credential in `./state`; the
credential is never returned to the browser or printed. The Guard sends only
decision metadata to the AccessProof control plane.

Advanced and automated deployments may still use the `accessproof-guard` CLI.
