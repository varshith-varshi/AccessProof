"""Framework-neutral safe RAG integration for an AccessProof Guard."""

from .protection import GuardClient, ProtectedRAG, ProtectedResponse, RetrievedResource
from .adapters import (
    ADAPTER_CONTRACT_VERSION,
    AdapterCapabilities,
    AdapterConfigurationError,
    HaystackAdapter,
    LangChainAdapter,
    LlamaIndexAdapter,
    RAGAdapter,
    adapter_capability_matrix,
    normalize_document,
    normalize_documents,
)
from .registry import AdapterRegistration, adapter_registry

__all__ = [
    "ADAPTER_CONTRACT_VERSION",
    "AdapterCapabilities",
    "AdapterConfigurationError",
    "AdapterRegistration",
    "GuardClient",
    "HaystackAdapter",
    "LangChainAdapter",
    "LlamaIndexAdapter",
    "ProtectedRAG",
    "ProtectedResponse",
    "RAGAdapter",
    "RetrievedResource",
    "adapter_capability_matrix",
    "adapter_registry",
    "normalize_document",
    "normalize_documents",
]
