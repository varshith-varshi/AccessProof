$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
  Write-Error "Docker Desktop is required. Install Docker Desktop, then run this launcher again."
}
if (-not (Test-Path ".env")) { Copy-Item ".env.example" ".env" }
New-Item -ItemType Directory -Force -Path "state" | Out-Null
docker compose -f compose.yml up -d --build guard
$port = if ($env:GUARD_PORT) { $env:GUARD_PORT } else { "8080" }
$url = "http://127.0.0.1:$port/setup"
for ($attempt = 0; $attempt -lt 60; $attempt++) {
  try { Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$port/health" -TimeoutSec 3 | Out-Null; break }
  catch { if ($attempt -eq 59) { throw "Guard did not become ready. Run: docker compose -f compose.yml logs guard" }; Start-Sleep -Seconds 1 }
}
Start-Process $url
Write-Host "AccessProof Guard setup is open at $url"
