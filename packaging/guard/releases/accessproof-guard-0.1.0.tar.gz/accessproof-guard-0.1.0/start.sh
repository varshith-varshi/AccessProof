#!/usr/bin/env sh
set -eu

cd "$(dirname "$0")"
if ! command -v docker >/dev/null 2>&1; then
  echo "Docker Desktop or Docker Engine is required. Install Docker, then run this launcher again."
  exit 1
fi
if [ ! -f .env ]; then
  cp .env.example .env
fi
mkdir -p state
docker compose -f compose.yml up -d --build guard
port="${GUARD_PORT:-8080}"
url="http://127.0.0.1:${port}/setup"
attempt=0
until curl -fsS "http://127.0.0.1:${port}/health" >/dev/null 2>&1; do
  attempt=$((attempt + 1))
  if [ "$attempt" -ge 60 ]; then
    echo "Guard did not become ready. Run: docker compose -f compose.yml logs guard"
    exit 1
  fi
  sleep 1
done
if command -v xdg-open >/dev/null 2>&1; then xdg-open "$url" >/dev/null 2>&1 || true
elif command -v open >/dev/null 2>&1; then open "$url" || true
fi
echo "AccessProof Guard setup is open at $url"
